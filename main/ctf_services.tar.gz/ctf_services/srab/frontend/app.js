import { routerNavigate, route } from "./router.js";
import {
  loadSession,
  clearSession,
  setTopUser,
  setLogoutVisible,
} from "./utils.js";
import "./views/auth.js";
import "./views/teacher.js";
import "./views/student.js";

route("/404", async ({ view }) => {
  const card = document.createElement("div");
  card.className = "card";
  card.innerHTML = `<div class="card-header">Страница не найдена</div><div class="card-body">Нет такой страницы</div>`;
  view.appendChild(card);
});

function initTop() {
  const s = loadSession();
  if (s) {
    setTopUser(s.username);
    setLogoutVisible(true);
  }
  document.getElementById("btn-logout").addEventListener("click", () => {
    clearSession();
    setTopUser("");
    setLogoutVisible(false);
    location.hash = "#/auth/login";
  });
}

window.addEventListener("DOMContentLoaded", () => {
  initTop();
  routerNavigate();
});
