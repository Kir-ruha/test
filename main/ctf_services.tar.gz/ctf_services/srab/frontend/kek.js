const API_BASE = (localStorage.getItem("srab.apiBase") || "").replace(
  /\/$/,
  ""
);

function buildAuthHeader(session) {
  if (!session || !session.username || !session.password) return {};
  return { Authorization: `Basic ${session.username} ${session.password}` };
}

async function apiFetch(
  path,
  { method = "GET", body, session, headers = {} } = {}
) {
  const url = `${API_BASE}${path}`;
  const h = {
    "Content-Type": "application/json",
    ...buildAuthHeader(session),
    ...headers,
  };
  const opts = { method, headers: h };
  if (body !== undefined)
    opts.body = typeof body === "string" ? body : JSON.stringify(body);

  const res = await fetch(url, opts);
  let data = null;
  const ct = res.headers.get("content-type") || "";
  data = await res.text();
  try {
    data = JSON.parse(data);
  } catch (e) {}

  if (!res.ok) {
    const err = new Error(
      (data && (data.message || data.error)) || `HTTP ${res.status}`
    );
    err.status = res.status;
    err.data = data;
    throw err;
  }
  return { status: res.status, data };
}

export const Api = {
  base: API_BASE,
  setBase(url) {
    localStorage.setItem("srab.apiBase", url);
  },

  async login({ username, password }) {
    const session = { username, password };
    const { data } = await apiFetch("/api/users/login", {
      method: "POST",
      session,
      body: { "имя пользователя": username, пароль: password },
    });
    return { session, message: data };
  },
  async registerTeacher(payload) {
    return apiFetch("/api/users", { method: "POST", body: payload });
  },
  async changePassword(session, newPassword) {
    return apiFetch("/api/users/password", {
      method: "PUT",
      session,
      body: { "новый пароль": newPassword },
    });
  },

  async listTeachers(session, page) {
    return apiFetch(
      `/api/teachers${page ? `?страница=${encodeURIComponent(page)}` : ""}`,
      { session }
    );
  },

  async createStudent(session, payload) {
    return apiFetch("/api/students", {
      method: "POST",
      session,
      body: payload,
    });
  },
  async listStudents(session, teacherId) {
    const q = teacherId ? `?учитель=${encodeURIComponent(teacherId)}` : "";
    return apiFetch(`/api/students${q}`, { session });
  },
  async getStudent(session, id) {
    return apiFetch(`/api/students/${id}`, { session });
  },
  async deleteStudent(session, id) {
    return apiFetch(`/api/students/${id}`, { method: "DELETE", session });
  },

  async listClasses(session, teacherId) {
    const q = teacherId ? `?учитель=${encodeURIComponent(teacherId)}` : "";
    return apiFetch(`/api/classes${q}`, { session });
  },
  async createClass(session, payload) {
    return apiFetch("/api/classes", { method: "POST", session, body: payload });
  },
  async deleteClass(session, classId) {
    return apiFetch(`/api/classes/${classId}`, { method: "DELETE", session });
  },
  async addStudentToClass(session, classId, studentId) {
    return apiFetch(`/api/classes/${classId}/students/${studentId}`, {
      method: "POST",
      session,
    });
  },
  async removeStudentFromClass(session, classId, studentId) {
    return apiFetch(`/api/classes/${classId}/students/${studentId}`, {
      method: "DELETE",
      session,
    });
  },

  async createLesson(session, classId, payload) {
    return apiFetch(`/api/classes/${classId}/lessons`, {
      method: "POST",
      session,
      body: payload,
    });
  },
  async listLessons(session, classId, date) {
    const q = date ? `?date=${encodeURIComponent(date)}` : "";
    return apiFetch(`/api/classes/${classId}/lessons${q}`, { session });
  },
  async listLessonsByDate(session, classId, date) {
    return apiFetch(`/api/classes/${classId}/lessons/date/${date}`, {
      session,
    });
  },
  async deleteLessonById(session, classId, lessonId) {
    return apiFetch(`/api/classes/${classId}/lessons/${lessonId}`, {
      method: "DELETE",
      session,
    });
  },
};
