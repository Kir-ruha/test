const routes = {};
export function route(path, handler) {
  routes[path] = handler;
}

function parseHash() {
  const h = location.hash.replace(/^#/, "");
  const parts = h.split("?");
  const path = parts[0] || "/dashboard";
  const search = new URLSearchParams(parts[1] || "");
  return { path, search };
}

export async function routerNavigate() {
  const { path, search } = parseHash();
  const view = document.getElementById("view");
  const handler = routes[path] || routes["/404"];
  view.innerHTML = "";
  await handler({ view, search });
  window.scrollTo(0, 0);
}

window.addEventListener("hashchange", routerNavigate);
