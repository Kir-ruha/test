#include "pstruya.h"

typedef struct {
    struya_vnutr__TStruya routine;
    TTagPair arg;
} tri_thread_launch_compound;

void* tri_thread_wrapper(void* arg) {
    tri_thread_launch_compound* compound = (tri_thread_launch_compound*) arg;
    compound->routine.func(compound->routine.receiver, compound->arg);

    free(compound);
    return NULL;
}

int64_t tri_thread_create(struya_vnutr__TStruya routine, TTagPair arg) {
    pthread_t thread;
    pthread_attr_t attr;

    pthread_attr_init(&attr);
    pthread_attr_setstacksize(&attr, 512 * 1024);

    tri_thread_launch_compound* compound = malloc(sizeof(tri_thread_launch_compound));
    compound->routine = routine;
    compound->arg = arg;

    int result = pthread_create(&thread, &attr, tri_thread_wrapper, (void*) compound);

    if (result != 0) {
        return 0;
    }

    return (int64_t)(uintptr_t)thread;
}

void tri_thread_join(int64_t thread) {
    if (!thread) return;
    
    pthread_join((pthread_t)(uintptr_t)thread, NULL);
}

void tri_thread_detach(int64_t thread) {
    if (!thread) return;

    pthread_detach((pthread_t)(uintptr_t)thread);
}
