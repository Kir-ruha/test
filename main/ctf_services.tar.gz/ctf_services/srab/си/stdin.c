#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include "rt_api.h"

TString stdin_read_to_string(int bytes) {
	if (bytes <= 0) {
		return tri_newString(0, 0, "");
	}

	char* buffer = (char*)malloc((size_t)bytes + 1);
	if (!buffer) {
		return tri_newString(0, 0, "");
	}

	ssize_t bytes_read = read(0, buffer, (size_t)bytes);
	if (bytes_read < 0) {
		bytes_read = 0;
	}

	TString string = tri_newString((int64_t)bytes_read, (int64_t)bytes_read, buffer);

	free(buffer);
	return string;
}

// Writes TString data to STDERR (fd 2)
void stderr_write_string(TString data) {
	if (!data) return;
	char* datastring = (char*)data->body;
	if (!datastring) return;
	write(2, datastring, (size_t)strlen(datastring));
}

