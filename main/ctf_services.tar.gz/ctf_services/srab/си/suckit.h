#ifndef SUCKIT_H
#define SUCKIT_H

#include "rt_api.h"

int create_socket_fd(int port);
int accept_socket(int fd);
void write_string(int socket, TString data);
void close_socket(int socket);
TString read_to_string(int socket, int bytes);
int connect_socket(TString host, int port);

#endif // SUCKIT_H
