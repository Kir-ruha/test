#ifndef STDIN_H
#define STDIN_H

#include "rt_api.h"

TString stdin_read_to_string(int bytes);
void stderr_write_string(TString data);

#endif // STDIN_H
