#ifndef STRUYA_H
#define STRUYA_H

#include "rt_api.h"
#include "struya_vnutr.h"

#include <pthread.h>
#include <stdlib.h>

int64_t tri_thread_create(struya_vnutr__TStruya routine, TTagPair arg);
void tri_thread_join(int64_t thread);
void tri_thread_detach(int64_t thread);

#endif // STRUYA_H
