#ifndef SCKULYA_H
#define SCKULYA_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "rt_api.h"

#include <sqlite3.h>

int64_t tri_sqlite_open(TString filename, TString *error);
int tri_sqlite_close(int64_t db);
void tri_sqlite_exec(int64_t db, TString query, TString *error);
int tri_sqlite_query(int64_t db, TString query, TString *result, TString *error);

#endif // SCKULYA_H
