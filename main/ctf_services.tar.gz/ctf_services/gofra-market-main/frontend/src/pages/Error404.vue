<template>
    <q-page class="flex flex-center text-center q-pa-md">
        <div>
            <div class="text-h1 text-primary">404</div>
            <div class="text-h4 q-mt-md q-mb-xl">Страница не найдена</div>
            <q-btn label="На главную" to="/" color="primary"/>
        </div>
    </q-page>
</template>

<script>
export default {
    name: 'Error404'
}
</script>