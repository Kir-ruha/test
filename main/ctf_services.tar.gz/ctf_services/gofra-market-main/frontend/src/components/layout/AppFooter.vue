<template>
    <q-footer elevated class="bg-grey-8 text-white">
        <q-toolbar>
            <q-toolbar-title class="text-center">
                <div>Gofra Market &copy; 2024</div>
                <div class="text-caption">Торговая площадка гоферов</div>
            </q-toolbar-title>
        </q-toolbar>
    </q-footer>
</template>

<script>
export default {
    name: 'AppFooter'
}
</script>