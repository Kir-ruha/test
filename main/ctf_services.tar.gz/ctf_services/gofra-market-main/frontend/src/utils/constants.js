export const RARITY_COLORS = {
  1: '#b8e6e2ff', 
  2: '#96cad4ff',
  3: '#13758bff' 
}

export const RARITY_NAMES = {
  1: 'Обычный',
  2: 'Редкий',
  3: 'Эпический'
}

export const INITIAL_BALANCE = 100
