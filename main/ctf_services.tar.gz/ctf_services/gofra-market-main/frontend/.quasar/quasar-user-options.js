/**
 * THIS FILE IS GENERATED AUTOMATICALLY.
 * DO NOT EDIT.
 *
 * You are probably looking on adding startup/initialization code.
 * Use "quasar new boot <name>" and add it there.
 * One boot file per concern. Then reference the file(s) in quasar.config.js > boot:
 * boot: ['file', ...] // do not add ".js" extension to it.
 *
 * Boot files are your "main.js"
 **/

import lang from 'quasar/lang/ru.js'

import iconSet from 'quasar/icon-set/material-icons.js'



import {Notify,Dialog} from 'quasar'



export default { config: {"brand":{"primary":"#D4B896","secondary":"#8B4513","accent":"#FF6B35","dark":"#2E2E2E","positive":"#21BA45","negative":"#C10015","info":"#31CCEC","warning":"#F2C037"}},lang,iconSet,plugins: {Notify,Dialog} }

